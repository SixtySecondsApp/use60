# Showcase Components

Standalone extracts of three key product features for demo/reference purposes.

## Contents

| File | Description |
|------|-------------|
| `v3-skills-onboarding/` | V3 Platform Skills configuration step during onboarding |
| `multi-agent-demo/` | Side-by-side single-agent vs multi-agent race demo |
| `copilot-empty-state/` | Copilot welcome screen with 4 quick action cards + chat |
